import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../1746d432-ba19-4b2e-819f-d16cf5a64236/src/item"
import Script2 from "../3e3df11c-8e39-4494-ac4e-d6faab495f13/src/item"
import Script3 from "../c1e126e7-374e-4fe3-aaae-b4211c321cf3/src/item"
import Script4 from "../b79a150e-5914-4fdf-a6b4-c7ff0c6833dd/src/item"
import Script5 from "../c4a799c1-9ef8-4787-914e-4f8c15357881/src/item"
import Script6 from "../b88efbbf-2a9a-47b4-86e1-e38ecc2b433b/src/item"
import { postData } from "./postData"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const videoScreenStanding = new Entity('videoScreenStanding')
engine.addEntity(videoScreenStanding)
videoScreenStanding.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(15, 0, 29.5),
  rotation: new Quaternion(1.7763568394002505e-15, -1, 1.1920928244535389e-7, -2.9802322387695312e-8),
  scale: new Vector3(1, 1, 1)
})
videoScreenStanding.addComponentOrReplace(transform2)

const armchairRed2 = new Entity('armchairRed2')
engine.addEntity(armchairRed2)
armchairRed2.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(29.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed2.addComponentOrReplace(transform3)
const gltfShape = new GLTFShape("dc2d6a5f-0dc7-4300-8015-46993a3c425d/RedArmchair.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
armchairRed2.addComponentOrReplace(gltfShape)

const checkerboardFloorPanel = new Entity('checkerboardFloorPanel')
engine.addEntity(checkerboardFloorPanel)
checkerboardFloorPanel.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(30, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel.addComponentOrReplace(transform4)
const gltfShape2 = new GLTFShape("428db18d-258b-476d-bde2-638ad3ab244b/FloorSciFiPanel_03/FloorSciFiPanel_03.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
checkerboardFloorPanel.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel2 = new Entity('checkerboardFloorPanel2')
engine.addEntity(checkerboardFloorPanel2)
checkerboardFloorPanel2.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(27, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel2.addComponentOrReplace(transform5)
checkerboardFloorPanel2.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel3 = new Entity('checkerboardFloorPanel3')
engine.addEntity(checkerboardFloorPanel3)
checkerboardFloorPanel3.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(24, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel3.addComponentOrReplace(transform6)
checkerboardFloorPanel3.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel4 = new Entity('checkerboardFloorPanel4')
engine.addEntity(checkerboardFloorPanel4)
checkerboardFloorPanel4.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(21, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel4.addComponentOrReplace(transform7)
checkerboardFloorPanel4.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel5 = new Entity('checkerboardFloorPanel5')
engine.addEntity(checkerboardFloorPanel5)
checkerboardFloorPanel5.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(18, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel5.addComponentOrReplace(transform8)
checkerboardFloorPanel5.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel6 = new Entity('checkerboardFloorPanel6')
engine.addEntity(checkerboardFloorPanel6)
checkerboardFloorPanel6.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(15, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel6.addComponentOrReplace(transform9)
checkerboardFloorPanel6.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel7 = new Entity('checkerboardFloorPanel7')
engine.addEntity(checkerboardFloorPanel7)
checkerboardFloorPanel7.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(12, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel7.addComponentOrReplace(transform10)
checkerboardFloorPanel7.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel8 = new Entity('checkerboardFloorPanel8')
engine.addEntity(checkerboardFloorPanel8)
checkerboardFloorPanel8.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(9, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel8.addComponentOrReplace(transform11)
checkerboardFloorPanel8.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel9 = new Entity('checkerboardFloorPanel9')
engine.addEntity(checkerboardFloorPanel9)
checkerboardFloorPanel9.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(6, 0, 9),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel9.addComponentOrReplace(transform12)
checkerboardFloorPanel9.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel10 = new Entity('checkerboardFloorPanel10')
engine.addEntity(checkerboardFloorPanel10)
checkerboardFloorPanel10.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(6, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel10.addComponentOrReplace(transform13)
checkerboardFloorPanel10.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel11 = new Entity('checkerboardFloorPanel11')
engine.addEntity(checkerboardFloorPanel11)
checkerboardFloorPanel11.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(9, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel11.addComponentOrReplace(transform14)
checkerboardFloorPanel11.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel12 = new Entity('checkerboardFloorPanel12')
engine.addEntity(checkerboardFloorPanel12)
checkerboardFloorPanel12.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(12, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel12.addComponentOrReplace(transform15)
checkerboardFloorPanel12.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel13 = new Entity('checkerboardFloorPanel13')
engine.addEntity(checkerboardFloorPanel13)
checkerboardFloorPanel13.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(15, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel13.addComponentOrReplace(transform16)
checkerboardFloorPanel13.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel14 = new Entity('checkerboardFloorPanel14')
engine.addEntity(checkerboardFloorPanel14)
checkerboardFloorPanel14.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(18, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel14.addComponentOrReplace(transform17)
checkerboardFloorPanel14.addComponentOrReplace(gltfShape2)

const ceilingXM = new Entity('ceilingXM')
engine.addEntity(ceilingXM)
ceilingXM.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(21, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ceilingXM.addComponentOrReplace(transform18)
const gltfShape3 = new GLTFShape("0efcf632-80ae-4c0b-94a9-7ebf7fd569b0/Ceiling 2x2M.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
ceilingXM.addComponentOrReplace(gltfShape3)

const ceilingXM2 = new Entity('ceilingXM2')
engine.addEntity(ceilingXM2)
ceilingXM2.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(24, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ceilingXM2.addComponentOrReplace(transform19)
ceilingXM2.addComponentOrReplace(gltfShape3)

const checkerboardFloorPanel16 = new Entity('checkerboardFloorPanel16')
engine.addEntity(checkerboardFloorPanel16)
checkerboardFloorPanel16.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(27, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel16.addComponentOrReplace(transform20)
checkerboardFloorPanel16.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel17 = new Entity('checkerboardFloorPanel17')
engine.addEntity(checkerboardFloorPanel17)
checkerboardFloorPanel17.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(30, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel17.addComponentOrReplace(transform21)
checkerboardFloorPanel17.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel18 = new Entity('checkerboardFloorPanel18')
engine.addEntity(checkerboardFloorPanel18)
checkerboardFloorPanel18.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(21, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel18.addComponentOrReplace(transform22)
checkerboardFloorPanel18.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel19 = new Entity('checkerboardFloorPanel19')
engine.addEntity(checkerboardFloorPanel19)
checkerboardFloorPanel19.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(15, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel19.addComponentOrReplace(transform23)
checkerboardFloorPanel19.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel20 = new Entity('checkerboardFloorPanel20')
engine.addEntity(checkerboardFloorPanel20)
checkerboardFloorPanel20.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(12, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel20.addComponentOrReplace(transform24)
checkerboardFloorPanel20.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel21 = new Entity('checkerboardFloorPanel21')
engine.addEntity(checkerboardFloorPanel21)
checkerboardFloorPanel21.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(9, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel21.addComponentOrReplace(transform25)
checkerboardFloorPanel21.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel22 = new Entity('checkerboardFloorPanel22')
engine.addEntity(checkerboardFloorPanel22)
checkerboardFloorPanel22.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(27, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel22.addComponentOrReplace(transform26)
checkerboardFloorPanel22.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel23 = new Entity('checkerboardFloorPanel23')
engine.addEntity(checkerboardFloorPanel23)
checkerboardFloorPanel23.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(21, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel23.addComponentOrReplace(transform27)
checkerboardFloorPanel23.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel24 = new Entity('checkerboardFloorPanel24')
engine.addEntity(checkerboardFloorPanel24)
checkerboardFloorPanel24.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(24, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel24.addComponentOrReplace(transform28)
checkerboardFloorPanel24.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel25 = new Entity('checkerboardFloorPanel25')
engine.addEntity(checkerboardFloorPanel25)
checkerboardFloorPanel25.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(18, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel25.addComponentOrReplace(transform29)
checkerboardFloorPanel25.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel26 = new Entity('checkerboardFloorPanel26')
engine.addEntity(checkerboardFloorPanel26)
checkerboardFloorPanel26.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(24, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel26.addComponentOrReplace(transform30)
checkerboardFloorPanel26.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel27 = new Entity('checkerboardFloorPanel27')
engine.addEntity(checkerboardFloorPanel27)
checkerboardFloorPanel27.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(18, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel27.addComponentOrReplace(transform31)
checkerboardFloorPanel27.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel28 = new Entity('checkerboardFloorPanel28')
engine.addEntity(checkerboardFloorPanel28)
checkerboardFloorPanel28.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(18, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel28.addComponentOrReplace(transform32)
checkerboardFloorPanel28.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel29 = new Entity('checkerboardFloorPanel29')
engine.addEntity(checkerboardFloorPanel29)
checkerboardFloorPanel29.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(18, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel29.addComponentOrReplace(transform33)
checkerboardFloorPanel29.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel30 = new Entity('checkerboardFloorPanel30')
engine.addEntity(checkerboardFloorPanel30)
checkerboardFloorPanel30.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(21, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel30.addComponentOrReplace(transform34)
checkerboardFloorPanel30.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel31 = new Entity('checkerboardFloorPanel31')
engine.addEntity(checkerboardFloorPanel31)
checkerboardFloorPanel31.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(15, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel31.addComponentOrReplace(transform35)
checkerboardFloorPanel31.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel32 = new Entity('checkerboardFloorPanel32')
engine.addEntity(checkerboardFloorPanel32)
checkerboardFloorPanel32.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(12, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel32.addComponentOrReplace(transform36)
checkerboardFloorPanel32.addComponentOrReplace(gltfShape2)

const checkerboardFloorPanel33 = new Entity('checkerboardFloorPanel33')
engine.addEntity(checkerboardFloorPanel33)
checkerboardFloorPanel33.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(15, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
checkerboardFloorPanel33.addComponentOrReplace(transform37)
checkerboardFloorPanel33.addComponentOrReplace(gltfShape2)

const armchairRed = new Entity('armchairRed')
engine.addEntity(armchairRed)
armchairRed.setParent(_scene)
armchairRed.addComponentOrReplace(gltfShape)
const transform38 = new Transform({
  position: new Vector3(26.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed.addComponentOrReplace(transform38)

const armchairRed3 = new Entity('armchairRed3')
engine.addEntity(armchairRed3)
armchairRed3.setParent(_scene)
armchairRed3.addComponentOrReplace(gltfShape)
const transform39 = new Transform({
  position: new Vector3(23.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed3.addComponentOrReplace(transform39)

const armchairRed4 = new Entity('armchairRed4')
engine.addEntity(armchairRed4)
armchairRed4.setParent(_scene)
armchairRed4.addComponentOrReplace(gltfShape)
const transform40 = new Transform({
  position: new Vector3(20.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed4.addComponentOrReplace(transform40)

const armchairRed5 = new Entity('armchairRed5')
engine.addEntity(armchairRed5)
armchairRed5.setParent(_scene)
armchairRed5.addComponentOrReplace(gltfShape)
const transform41 = new Transform({
  position: new Vector3(5.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed5.addComponentOrReplace(transform41)

const armchairRed6 = new Entity('armchairRed6')
engine.addEntity(armchairRed6)
armchairRed6.setParent(_scene)
armchairRed6.addComponentOrReplace(gltfShape)
const transform42 = new Transform({
  position: new Vector3(8.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed6.addComponentOrReplace(transform42)

const armchairRed7 = new Entity('armchairRed7')
engine.addEntity(armchairRed7)
armchairRed7.setParent(_scene)
armchairRed7.addComponentOrReplace(gltfShape)
const transform43 = new Transform({
  position: new Vector3(11.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed7.addComponentOrReplace(transform43)

const armchairRed8 = new Entity('armchairRed8')
engine.addEntity(armchairRed8)
armchairRed8.setParent(_scene)
armchairRed8.addComponentOrReplace(gltfShape)
const transform44 = new Transform({
  position: new Vector3(14.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed8.addComponentOrReplace(transform44)

const armchairRed9 = new Entity('armchairRed9')
engine.addEntity(armchairRed9)
armchairRed9.setParent(_scene)
armchairRed9.addComponentOrReplace(gltfShape)
const transform45 = new Transform({
  position: new Vector3(17.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed9.addComponentOrReplace(transform45)

const armchairRed10 = new Entity('armchairRed10')
engine.addEntity(armchairRed10)
armchairRed10.setParent(_scene)
armchairRed10.addComponentOrReplace(gltfShape)
const transform46 = new Transform({
  position: new Vector3(26.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed10.addComponentOrReplace(transform46)

const armchairRed11 = new Entity('armchairRed11')
engine.addEntity(armchairRed11)
armchairRed11.setParent(_scene)
armchairRed11.addComponentOrReplace(gltfShape)
const transform47 = new Transform({
  position: new Vector3(23.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed11.addComponentOrReplace(transform47)

const armchairRed12 = new Entity('armchairRed12')
engine.addEntity(armchairRed12)
armchairRed12.setParent(_scene)
armchairRed12.addComponentOrReplace(gltfShape)
const transform48 = new Transform({
  position: new Vector3(20.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed12.addComponentOrReplace(transform48)

const armchairRed13 = new Entity('armchairRed13')
engine.addEntity(armchairRed13)
armchairRed13.setParent(_scene)
armchairRed13.addComponentOrReplace(gltfShape)
const transform49 = new Transform({
  position: new Vector3(17.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed13.addComponentOrReplace(transform49)

const armchairRed14 = new Entity('armchairRed14')
engine.addEntity(armchairRed14)
armchairRed14.setParent(_scene)
armchairRed14.addComponentOrReplace(gltfShape)
const transform50 = new Transform({
  position: new Vector3(14.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed14.addComponentOrReplace(transform50)

const armchairRed15 = new Entity('armchairRed15')
engine.addEntity(armchairRed15)
armchairRed15.setParent(_scene)
armchairRed15.addComponentOrReplace(gltfShape)
const transform51 = new Transform({
  position: new Vector3(11.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed15.addComponentOrReplace(transform51)

const armchairRed16 = new Entity('armchairRed16')
engine.addEntity(armchairRed16)
armchairRed16.setParent(_scene)
armchairRed16.addComponentOrReplace(gltfShape)
const transform52 = new Transform({
  position: new Vector3(8.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed16.addComponentOrReplace(transform52)

const armchairRed17 = new Entity('armchairRed17')
engine.addEntity(armchairRed17)
armchairRed17.setParent(_scene)
armchairRed17.addComponentOrReplace(gltfShape)
const transform53 = new Transform({
  position: new Vector3(5.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed17.addComponentOrReplace(transform53)

const armchairRed18 = new Entity('armchairRed18')
engine.addEntity(armchairRed18)
armchairRed18.setParent(_scene)
armchairRed18.addComponentOrReplace(gltfShape)
const transform54 = new Transform({
  position: new Vector3(29.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed18.addComponentOrReplace(transform54)

const armchairRed19 = new Entity('armchairRed19')
engine.addEntity(armchairRed19)
armchairRed19.setParent(_scene)
armchairRed19.addComponentOrReplace(gltfShape)
const transform55 = new Transform({
  position: new Vector3(26.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed19.addComponentOrReplace(transform55)

const armchairRed20 = new Entity('armchairRed20')
engine.addEntity(armchairRed20)
armchairRed20.setParent(_scene)
armchairRed20.addComponentOrReplace(gltfShape)
const transform56 = new Transform({
  position: new Vector3(23.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed20.addComponentOrReplace(transform56)

const armchairRed21 = new Entity('armchairRed21')
engine.addEntity(armchairRed21)
armchairRed21.setParent(_scene)
armchairRed21.addComponentOrReplace(gltfShape)
const transform57 = new Transform({
  position: new Vector3(20.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed21.addComponentOrReplace(transform57)

const armchairRed22 = new Entity('armchairRed22')
engine.addEntity(armchairRed22)
armchairRed22.setParent(_scene)
armchairRed22.addComponentOrReplace(gltfShape)
const transform58 = new Transform({
  position: new Vector3(17.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed22.addComponentOrReplace(transform58)

const armchairRed23 = new Entity('armchairRed23')
engine.addEntity(armchairRed23)
armchairRed23.setParent(_scene)
armchairRed23.addComponentOrReplace(gltfShape)
const transform59 = new Transform({
  position: new Vector3(14.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed23.addComponentOrReplace(transform59)

const armchairRed24 = new Entity('armchairRed24')
engine.addEntity(armchairRed24)
armchairRed24.setParent(_scene)
armchairRed24.addComponentOrReplace(gltfShape)
const transform60 = new Transform({
  position: new Vector3(11.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed24.addComponentOrReplace(transform60)

const armchairRed25 = new Entity('armchairRed25')
engine.addEntity(armchairRed25)
armchairRed25.setParent(_scene)
armchairRed25.addComponentOrReplace(gltfShape)
const transform61 = new Transform({
  position: new Vector3(8.5, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed25.addComponentOrReplace(transform61)

const armchairRed26 = new Entity('armchairRed26')
engine.addEntity(armchairRed26)
armchairRed26.setParent(_scene)
armchairRed26.addComponentOrReplace(gltfShape)
const transform62 = new Transform({
  position: new Vector3(23.5, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed26.addComponentOrReplace(transform62)

const armchairRed27 = new Entity('armchairRed27')
engine.addEntity(armchairRed27)
armchairRed27.setParent(_scene)
armchairRed27.addComponentOrReplace(gltfShape)
const transform63 = new Transform({
  position: new Vector3(20.5, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed27.addComponentOrReplace(transform63)

const armchairRed28 = new Entity('armchairRed28')
engine.addEntity(armchairRed28)
armchairRed28.setParent(_scene)
armchairRed28.addComponentOrReplace(gltfShape)
const transform64 = new Transform({
  position: new Vector3(17.5, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed28.addComponentOrReplace(transform64)

const armchairRed29 = new Entity('armchairRed29')
engine.addEntity(armchairRed29)
armchairRed29.setParent(_scene)
armchairRed29.addComponentOrReplace(gltfShape)
const transform65 = new Transform({
  position: new Vector3(14.5, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed29.addComponentOrReplace(transform65)

const armchairRed30 = new Entity('armchairRed30')
engine.addEntity(armchairRed30)
armchairRed30.setParent(_scene)
armchairRed30.addComponentOrReplace(gltfShape)
const transform66 = new Transform({
  position: new Vector3(11.5, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed30.addComponentOrReplace(transform66)

const armchairRed31 = new Entity('armchairRed31')
engine.addEntity(armchairRed31)
armchairRed31.setParent(_scene)
armchairRed31.addComponentOrReplace(gltfShape)
const transform67 = new Transform({
  position: new Vector3(20.5, 0, 20.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed31.addComponentOrReplace(transform67)

const armchairRed32 = new Entity('armchairRed32')
engine.addEntity(armchairRed32)
armchairRed32.setParent(_scene)
armchairRed32.addComponentOrReplace(gltfShape)
const transform68 = new Transform({
  position: new Vector3(17.5, 0, 20.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed32.addComponentOrReplace(transform68)

const armchairRed33 = new Entity('armchairRed33')
engine.addEntity(armchairRed33)
armchairRed33.setParent(_scene)
armchairRed33.addComponentOrReplace(gltfShape)
const transform69 = new Transform({
  position: new Vector3(14.5, 0, 20.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed33.addComponentOrReplace(transform69)

const armchairRed34 = new Entity('armchairRed34')
engine.addEntity(armchairRed34)
armchairRed34.setParent(_scene)
armchairRed34.addComponentOrReplace(gltfShape)
const transform70 = new Transform({
  position: new Vector3(17.5, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
armchairRed34.addComponentOrReplace(transform70)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape4 = new GLTFShape("6b33f46e-9667-45e5-bd90-85f372ee2490/CityTile.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
entity.addComponentOrReplace(gltfShape4)
const transform71 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform71)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape4)
const transform72 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform72)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape4)
const transform73 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform73)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape4)
const transform74 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform74)

const atomicLight = new Entity('atomicLight')
engine.addEntity(atomicLight)
atomicLight.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(15, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, -2.2049999237060547, 1)
})
atomicLight.addComponentOrReplace(transform75)





const galleryInfoBlack = new Entity('galleryInfoBlack')
engine.addEntity(galleryInfoBlack)
galleryInfoBlack.setParent(_scene)

const transform76 = new Transform({
  position: new Vector3(23.5, 0, 29.5),
  rotation: new Quaternion(-3.001343511015945e-15, -1, 1.1920927533992653e-7, -1.4901161193847656e-8),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
galleryInfoBlack.addComponentOrReplace(transform76)


const blockFloorLight = new Entity('blockFloorLight')
engine.addEntity(blockFloorLight)
blockFloorLight.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(15, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
blockFloorLight.addComponentOrReplace(transform77)

const couchThreeSeater = new Entity('couchThreeSeater')
engine.addEntity(couchThreeSeater)
couchThreeSeater.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(25, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
couchThreeSeater.addComponentOrReplace(transform78)
const gltfShape5 = new GLTFShape("7ec82823-7d54-4456-9a88-faf48f6098e1/ThreeSeater_Couch.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
couchThreeSeater.addComponentOrReplace(gltfShape5)

const couchThreeSeater2 = new Entity('couchThreeSeater2')
engine.addEntity(couchThreeSeater2)
couchThreeSeater2.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(12, 0, 22),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
couchThreeSeater2.addComponentOrReplace(transform79)
couchThreeSeater2.addComponentOrReplace(gltfShape5)

const couchThreeSeater3 = new Entity('couchThreeSeater3')
engine.addEntity(couchThreeSeater3)
couchThreeSeater3.setParent(_scene)
couchThreeSeater3.addComponentOrReplace(gltfShape5)
const transform80 = new Transform({
  position: new Vector3(12, 0, 24.25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
couchThreeSeater3.addComponentOrReplace(transform80)

const couchThreeSeater4 = new Entity('couchThreeSeater4')
engine.addEntity(couchThreeSeater4)
couchThreeSeater4.setParent(_scene)
couchThreeSeater4.addComponentOrReplace(gltfShape5)
const transform81 = new Transform({
  position: new Vector3(25, 0, 23.75),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
couchThreeSeater4.addComponentOrReplace(transform81)

const doorframeDiagonalBoard = new Entity('doorframeDiagonalBoard')
engine.addEntity(doorframeDiagonalBoard)
doorframeDiagonalBoard.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(17, 0, 0.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
doorframeDiagonalBoard.addComponentOrReplace(transform82)
const gltfShape6 = new GLTFShape("42d60765-8482-47f2-9a76-58a2560d7ced/DiagonalBoardDoorframe.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
doorframeDiagonalBoard.addComponentOrReplace(gltfShape6)

const blockFloorLight2 = new Entity('blockFloorLight2')
engine.addEntity(blockFloorLight2)
blockFloorLight2.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(15, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
blockFloorLight2.addComponentOrReplace(transform83)

const blockFloorLight3 = new Entity('blockFloorLight3')
engine.addEntity(blockFloorLight3)
blockFloorLight3.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(17.5, 0, 2.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
blockFloorLight3.addComponentOrReplace(transform84)

const roofBeige = new Entity('roofBeige')
engine.addEntity(roofBeige)
roofBeige.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(4.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige.addComponentOrReplace(transform85)
const gltfShape7 = new GLTFShape("9b026726-cba9-454d-bb4f-aece85632869/BeigeRoof.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
roofBeige.addComponentOrReplace(gltfShape7)

const roofBeige2 = new Entity('roofBeige2')
engine.addEntity(roofBeige2)
roofBeige2.setParent(_scene)
roofBeige2.addComponentOrReplace(gltfShape7)
const transform86 = new Transform({
  position: new Vector3(8.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige2.addComponentOrReplace(transform86)

const roofBeige3 = new Entity('roofBeige3')
engine.addEntity(roofBeige3)
roofBeige3.setParent(_scene)
roofBeige3.addComponentOrReplace(gltfShape7)
const transform87 = new Transform({
  position: new Vector3(12.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige3.addComponentOrReplace(transform87)

const roofBeige4 = new Entity('roofBeige4')
engine.addEntity(roofBeige4)
roofBeige4.setParent(_scene)
roofBeige4.addComponentOrReplace(gltfShape7)
const transform88 = new Transform({
  position: new Vector3(24.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige4.addComponentOrReplace(transform88)

const roofBeige5 = new Entity('roofBeige5')
engine.addEntity(roofBeige5)
roofBeige5.setParent(_scene)
roofBeige5.addComponentOrReplace(gltfShape7)
const transform89 = new Transform({
  position: new Vector3(20.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige5.addComponentOrReplace(transform89)

const roofBeige6 = new Entity('roofBeige6')
engine.addEntity(roofBeige6)
roofBeige6.setParent(_scene)
roofBeige6.addComponentOrReplace(gltfShape7)
const transform90 = new Transform({
  position: new Vector3(16.375, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige6.addComponentOrReplace(transform90)

const roofBeige7 = new Entity('roofBeige7')
engine.addEntity(roofBeige7)
roofBeige7.setParent(_scene)
roofBeige7.addComponentOrReplace(gltfShape7)
const transform91 = new Transform({
  position: new Vector3(31.875, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige7.addComponentOrReplace(transform91)

const roofBeige9 = new Entity('roofBeige9')
engine.addEntity(roofBeige9)
roofBeige9.setParent(_scene)
roofBeige9.addComponentOrReplace(gltfShape7)
const transform92 = new Transform({
  position: new Vector3(27.875, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige9.addComponentOrReplace(transform92)

const roofBeige8 = new Entity('roofBeige8')
engine.addEntity(roofBeige8)
roofBeige8.setParent(_scene)
roofBeige8.addComponentOrReplace(gltfShape7)
const transform93 = new Transform({
  position: new Vector3(31.75, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige8.addComponentOrReplace(transform93)

const roofBeige10 = new Entity('roofBeige10')
engine.addEntity(roofBeige10)
roofBeige10.setParent(_scene)
roofBeige10.addComponentOrReplace(gltfShape7)
const transform94 = new Transform({
  position: new Vector3(27.625, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige10.addComponentOrReplace(transform94)

const roofBeige11 = new Entity('roofBeige11')
engine.addEntity(roofBeige11)
roofBeige11.setParent(_scene)
roofBeige11.addComponentOrReplace(gltfShape7)
const transform95 = new Transform({
  position: new Vector3(24.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige11.addComponentOrReplace(transform95)

const roofBeige12 = new Entity('roofBeige12')
engine.addEntity(roofBeige12)
roofBeige12.setParent(_scene)
roofBeige12.addComponentOrReplace(gltfShape7)
const transform96 = new Transform({
  position: new Vector3(20.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige12.addComponentOrReplace(transform96)

const roofBeige13 = new Entity('roofBeige13')
engine.addEntity(roofBeige13)
roofBeige13.setParent(_scene)
roofBeige13.addComponentOrReplace(gltfShape7)
const transform97 = new Transform({
  position: new Vector3(16.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige13.addComponentOrReplace(transform97)

const roofBeige14 = new Entity('roofBeige14')
engine.addEntity(roofBeige14)
roofBeige14.setParent(_scene)
roofBeige14.addComponentOrReplace(gltfShape7)
const transform98 = new Transform({
  position: new Vector3(12.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige14.addComponentOrReplace(transform98)

const roofBeige15 = new Entity('roofBeige15')
engine.addEntity(roofBeige15)
roofBeige15.setParent(_scene)
roofBeige15.addComponentOrReplace(gltfShape7)
const transform99 = new Transform({
  position: new Vector3(8.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige15.addComponentOrReplace(transform99)

const roofBeige16 = new Entity('roofBeige16')
engine.addEntity(roofBeige16)
roofBeige16.setParent(_scene)
roofBeige16.addComponentOrReplace(gltfShape7)
const transform100 = new Transform({
  position: new Vector3(4.125, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige16.addComponentOrReplace(transform100)

const roofBeige17 = new Entity('roofBeige17')
engine.addEntity(roofBeige17)
roofBeige17.setParent(_scene)
roofBeige17.addComponentOrReplace(gltfShape7)
const transform101 = new Transform({
  position: new Vector3(31.75, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige17.addComponentOrReplace(transform101)

const roofBeige18 = new Entity('roofBeige18')
engine.addEntity(roofBeige18)
roofBeige18.setParent(_scene)
roofBeige18.addComponentOrReplace(gltfShape7)
const transform102 = new Transform({
  position: new Vector3(27.625, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige18.addComponentOrReplace(transform102)

const roofBeige19 = new Entity('roofBeige19')
engine.addEntity(roofBeige19)
roofBeige19.setParent(_scene)
roofBeige19.addComponentOrReplace(gltfShape7)
const transform103 = new Transform({
  position: new Vector3(24.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige19.addComponentOrReplace(transform103)

const roofBeige20 = new Entity('roofBeige20')
engine.addEntity(roofBeige20)
roofBeige20.setParent(_scene)
roofBeige20.addComponentOrReplace(gltfShape7)
const transform104 = new Transform({
  position: new Vector3(20.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige20.addComponentOrReplace(transform104)

const roofBeige21 = new Entity('roofBeige21')
engine.addEntity(roofBeige21)
roofBeige21.setParent(_scene)
roofBeige21.addComponentOrReplace(gltfShape7)
const transform105 = new Transform({
  position: new Vector3(16.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige21.addComponentOrReplace(transform105)

const roofBeige22 = new Entity('roofBeige22')
engine.addEntity(roofBeige22)
roofBeige22.setParent(_scene)
roofBeige22.addComponentOrReplace(gltfShape7)
const transform106 = new Transform({
  position: new Vector3(12.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige22.addComponentOrReplace(transform106)

const roofBeige23 = new Entity('roofBeige23')
engine.addEntity(roofBeige23)
roofBeige23.setParent(_scene)
roofBeige23.addComponentOrReplace(gltfShape7)
const transform107 = new Transform({
  position: new Vector3(8.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige23.addComponentOrReplace(transform107)

const roofBeige24 = new Entity('roofBeige24')
engine.addEntity(roofBeige24)
roofBeige24.setParent(_scene)
roofBeige24.addComponentOrReplace(gltfShape7)
const transform108 = new Transform({
  position: new Vector3(4.125, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige24.addComponentOrReplace(transform108)

const roofBeige25 = new Entity('roofBeige25')
engine.addEntity(roofBeige25)
roofBeige25.setParent(_scene)
roofBeige25.addComponentOrReplace(gltfShape7)
const transform109 = new Transform({
  position: new Vector3(31.75, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige25.addComponentOrReplace(transform109)

const roofBeige26 = new Entity('roofBeige26')
engine.addEntity(roofBeige26)
roofBeige26.setParent(_scene)
roofBeige26.addComponentOrReplace(gltfShape7)
const transform110 = new Transform({
  position: new Vector3(27.625, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige26.addComponentOrReplace(transform110)

const roofBeige27 = new Entity('roofBeige27')
engine.addEntity(roofBeige27)
roofBeige27.setParent(_scene)
roofBeige27.addComponentOrReplace(gltfShape7)
const transform111 = new Transform({
  position: new Vector3(24.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige27.addComponentOrReplace(transform111)

const roofBeige28 = new Entity('roofBeige28')
engine.addEntity(roofBeige28)
roofBeige28.setParent(_scene)
roofBeige28.addComponentOrReplace(gltfShape7)
const transform112 = new Transform({
  position: new Vector3(20.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige28.addComponentOrReplace(transform112)

const roofBeige29 = new Entity('roofBeige29')
engine.addEntity(roofBeige29)
roofBeige29.setParent(_scene)
roofBeige29.addComponentOrReplace(gltfShape7)
const transform113 = new Transform({
  position: new Vector3(16.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige29.addComponentOrReplace(transform113)

const roofBeige30 = new Entity('roofBeige30')
engine.addEntity(roofBeige30)
roofBeige30.setParent(_scene)
roofBeige30.addComponentOrReplace(gltfShape7)
const transform114 = new Transform({
  position: new Vector3(12.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige30.addComponentOrReplace(transform114)

const roofBeige31 = new Entity('roofBeige31')
engine.addEntity(roofBeige31)
roofBeige31.setParent(_scene)
roofBeige31.addComponentOrReplace(gltfShape7)
const transform115 = new Transform({
  position: new Vector3(8.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige31.addComponentOrReplace(transform115)

const roofBeige32 = new Entity('roofBeige32')
engine.addEntity(roofBeige32)
roofBeige32.setParent(_scene)
roofBeige32.addComponentOrReplace(gltfShape7)
const transform116 = new Transform({
  position: new Vector3(4.125, 0, 17.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige32.addComponentOrReplace(transform116)

const roofBeige33 = new Entity('roofBeige33')
engine.addEntity(roofBeige33)
roofBeige33.setParent(_scene)
roofBeige33.addComponentOrReplace(gltfShape7)
const transform117 = new Transform({
  position: new Vector3(31.75, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige33.addComponentOrReplace(transform117)

const roofBeige34 = new Entity('roofBeige34')
engine.addEntity(roofBeige34)
roofBeige34.setParent(_scene)
roofBeige34.addComponentOrReplace(gltfShape7)
const transform118 = new Transform({
  position: new Vector3(27.625, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige34.addComponentOrReplace(transform118)

const roofBeige35 = new Entity('roofBeige35')
engine.addEntity(roofBeige35)
roofBeige35.setParent(_scene)
roofBeige35.addComponentOrReplace(gltfShape7)
const transform119 = new Transform({
  position: new Vector3(24.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige35.addComponentOrReplace(transform119)

const roofBeige36 = new Entity('roofBeige36')
engine.addEntity(roofBeige36)
roofBeige36.setParent(_scene)
roofBeige36.addComponentOrReplace(gltfShape7)
const transform120 = new Transform({
  position: new Vector3(20.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige36.addComponentOrReplace(transform120)

const roofBeige37 = new Entity('roofBeige37')
engine.addEntity(roofBeige37)
roofBeige37.setParent(_scene)
roofBeige37.addComponentOrReplace(gltfShape7)
const transform121 = new Transform({
  position: new Vector3(16.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige37.addComponentOrReplace(transform121)

const roofBeige38 = new Entity('roofBeige38')
engine.addEntity(roofBeige38)
roofBeige38.setParent(_scene)
roofBeige38.addComponentOrReplace(gltfShape7)
const transform122 = new Transform({
  position: new Vector3(12.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige38.addComponentOrReplace(transform122)

const roofBeige39 = new Entity('roofBeige39')
engine.addEntity(roofBeige39)
roofBeige39.setParent(_scene)
roofBeige39.addComponentOrReplace(gltfShape7)
const transform123 = new Transform({
  position: new Vector3(8.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige39.addComponentOrReplace(transform123)

const roofBeige40 = new Entity('roofBeige40')
engine.addEntity(roofBeige40)
roofBeige40.setParent(_scene)
roofBeige40.addComponentOrReplace(gltfShape7)
const transform124 = new Transform({
  position: new Vector3(4.125, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige40.addComponentOrReplace(transform124)

const roofBeige41 = new Entity('roofBeige41')
engine.addEntity(roofBeige41)
roofBeige41.setParent(_scene)
roofBeige41.addComponentOrReplace(gltfShape7)
const transform125 = new Transform({
  position: new Vector3(31.75, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige41.addComponentOrReplace(transform125)

const roofBeige42 = new Entity('roofBeige42')
engine.addEntity(roofBeige42)
roofBeige42.setParent(_scene)
roofBeige42.addComponentOrReplace(gltfShape7)
const transform126 = new Transform({
  position: new Vector3(27.625, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige42.addComponentOrReplace(transform126)

const roofBeige43 = new Entity('roofBeige43')
engine.addEntity(roofBeige43)
roofBeige43.setParent(_scene)
roofBeige43.addComponentOrReplace(gltfShape7)
const transform127 = new Transform({
  position: new Vector3(24.125, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige43.addComponentOrReplace(transform127)

const roofBeige44 = new Entity('roofBeige44')
engine.addEntity(roofBeige44)
roofBeige44.setParent(_scene)
roofBeige44.addComponentOrReplace(gltfShape7)
const transform128 = new Transform({
  position: new Vector3(20.125, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige44.addComponentOrReplace(transform128)

const roofBeige45 = new Entity('roofBeige45')
engine.addEntity(roofBeige45)
roofBeige45.setParent(_scene)
roofBeige45.addComponentOrReplace(gltfShape7)
const transform129 = new Transform({
  position: new Vector3(16.125, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige45.addComponentOrReplace(transform129)

const roofBeige46 = new Entity('roofBeige46')
engine.addEntity(roofBeige46)
roofBeige46.setParent(_scene)
roofBeige46.addComponentOrReplace(gltfShape7)
const transform130 = new Transform({
  position: new Vector3(12.125, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige46.addComponentOrReplace(transform130)

const roofBeige47 = new Entity('roofBeige47')
engine.addEntity(roofBeige47)
roofBeige47.setParent(_scene)
roofBeige47.addComponentOrReplace(gltfShape7)
const transform131 = new Transform({
  position: new Vector3(8.25, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige47.addComponentOrReplace(transform131)

const roofBeige48 = new Entity('roofBeige48')
engine.addEntity(roofBeige48)
roofBeige48.setParent(_scene)
roofBeige48.addComponentOrReplace(gltfShape7)
const transform132 = new Transform({
  position: new Vector3(4.125, 0, 25.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige48.addComponentOrReplace(transform132)

const roofBeige49 = new Entity('roofBeige49')
engine.addEntity(roofBeige49)
roofBeige49.setParent(_scene)
roofBeige49.addComponentOrReplace(gltfShape7)
const transform133 = new Transform({
  position: new Vector3(31.75, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige49.addComponentOrReplace(transform133)

const roofBeige50 = new Entity('roofBeige50')
engine.addEntity(roofBeige50)
roofBeige50.setParent(_scene)
roofBeige50.addComponentOrReplace(gltfShape7)
const transform134 = new Transform({
  position: new Vector3(27.625, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige50.addComponentOrReplace(transform134)

const roofBeige51 = new Entity('roofBeige51')
engine.addEntity(roofBeige51)
roofBeige51.setParent(_scene)
roofBeige51.addComponentOrReplace(gltfShape7)
const transform135 = new Transform({
  position: new Vector3(24.125, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige51.addComponentOrReplace(transform135)

const roofBeige52 = new Entity('roofBeige52')
engine.addEntity(roofBeige52)
roofBeige52.setParent(_scene)
roofBeige52.addComponentOrReplace(gltfShape7)
const transform136 = new Transform({
  position: new Vector3(20.25, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige52.addComponentOrReplace(transform136)

const roofBeige53 = new Entity('roofBeige53')
engine.addEntity(roofBeige53)
roofBeige53.setParent(_scene)
roofBeige53.addComponentOrReplace(gltfShape7)
const transform137 = new Transform({
  position: new Vector3(16.25, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige53.addComponentOrReplace(transform137)

const roofBeige54 = new Entity('roofBeige54')
engine.addEntity(roofBeige54)
roofBeige54.setParent(_scene)
roofBeige54.addComponentOrReplace(gltfShape7)
const transform138 = new Transform({
  position: new Vector3(12.25, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige54.addComponentOrReplace(transform138)

const roofBeige55 = new Entity('roofBeige55')
engine.addEntity(roofBeige55)
roofBeige55.setParent(_scene)
roofBeige55.addComponentOrReplace(gltfShape7)
const transform139 = new Transform({
  position: new Vector3(8.25, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige55.addComponentOrReplace(transform139)

const roofBeige56 = new Entity('roofBeige56')
engine.addEntity(roofBeige56)
roofBeige56.setParent(_scene)
roofBeige56.addComponentOrReplace(gltfShape7)
const transform140 = new Transform({
  position: new Vector3(4.25, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1)
})
roofBeige56.addComponentOrReplace(transform140)

const imageBillboardBlack = new Entity('imageBillboardBlack')
engine.addEntity(imageBillboardBlack)
imageBillboardBlack.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(3, 0, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imageBillboardBlack.addComponentOrReplace(transform141)

const externalLink = new Entity('externalLink')
engine.addEntity(externalLink)
externalLink.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(30, 0, 21),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
externalLink.addComponentOrReplace(transform142)

// const galleryInfoBlack = new Entity('galleryInfoBlack')
// engine.addEntity(galleryInfoBlack)
// galleryInfoBlack.setParent(_scene)

// const transform76 = new Transform({
//   position: new Vector3(23.5, 0, 29.5),
//   rotation: new Quaternion(-3.001343511015945e-15, -1, 1.1920927533992653e-7, -1.4901161193847656e-8),
//   scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
// })
// galleryInfoBlack.addComponentOrReplace(transform76)

const canvas = new UICanvas()

const data = {}

const emailInput = new UIInputText(canvas)
emailInput.width = "30%"
emailInput.height = "55px"
emailInput.vAlign = "bottom"
emailInput.hAlign = "center"
emailInput.fontSize = 20
emailInput.placeholder = "Enter Your Email"
emailInput.visible = false
emailInput.focusedBackground = Color4.Gray()
// emailInput.placeholderColor = Color4.Gray()
emailInput.positionY = "200px"
emailInput.isPointerBlocker = true

emailInput.onTextSubmit = new OnTextSubmit(async (x) => {
  const text = new UIText(emailInput)
  log(text);
  data['Email__c'] = x.text
  // text.value = "<USER-ID> " + x.text
  text.width = "100%"
  text.height = "80px"
  text.vAlign = "top"
  text.hAlign = "left"
  emailInput.visible = false
  firstName.visible = true
  // await postData("http://localhost:8001/create", { email__c: x.text })
  // firstName.visible = true
})
const firstName = new UIInputText(canvas)
firstName.width = "30%"
firstName.height = "55px"
firstName.vAlign = "bottom"
firstName.hAlign = "center"
firstName.fontSize = 20
firstName.focusedBackground = Color4.Blue()
firstName.placeholder = "Enter Your Name"
firstName.visible = false
// emailInput.placeholderColor = Color4.Gray()
firstName.positionY = "270px"
firstName.isPointerBlocker = true

firstName.onTextSubmit = new OnTextSubmit(async (x) => {
  const fname = new UIText(firstName)
  log(fname);
  // fname.value = "<USER-ID> " + x.text
  data['Name__c'] = x.text
  fname.width = "100%"
  fname.height = "20px"
  fname.vAlign = "top"
  fname.hAlign = "left"
  firstName.visible = false
  await postData("http://localhost:8001/create", data)
})

const uiTrigger = new Entity()
const transform143555 = new Transform({
  position: new Vector3(20, 1, 28),
  rotation: new Quaternion(-3.001343511015945e-15, -1, 1.1920927533992653e-7, -1.4901161193847656e-8),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
uiTrigger.addComponent(transform143555)

uiTrigger.addComponent(
  new OnPointerDown(() => {
    if (emailInput.visible) {
      emailInput.visible = false
      firstName.visible = false
      emailInput.isPointerBlocker = false
    } else {

      emailInput.visible = true
      // firstName.visible = true
      emailInput.isPointerBlocker = true
    }
  })
)

uiTrigger.addComponent(new GLTFShape("models/Book_01.glb"))
engine.addEntity(uiTrigger)
const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
script1.init()
script2.init()
script3.init()
script4.init()
script5.init()
script6.init()
script1.spawn(videoScreenStanding, { "startOn": true, "onClickText": "Play video", "volume": 1, "onClick": [{ "entityName": "videoScreenStanding", "actionId": "activate", "values": {} }], "station": "https://theuniverse.club/live/genesisplaza/index.m3u8", "onActivate": [], "image": "https://source.unsplash.com/random", "customStation": "https://www.youtube.com/watch?v=e1BxHIS9TMc" }, createChannel(channelId, videoScreenStanding, channelBus))
script2.spawn(atomicLight, { "startOn": true, "clickable": true }, createChannel(channelId, atomicLight, channelBus))
script3.spawn(galleryInfoBlack, { "text": "Hi All!", "fontSize": 10, "font": "SF_Heavy", "color": "#008080" }, createChannel(channelId, galleryInfoBlack, channelBus))
script4.spawn(blockFloorLight, { "startOn": true, "clickable": true }, createChannel(channelId, blockFloorLight, channelBus))
script4.spawn(blockFloorLight2, { "startOn": true, "clickable": true }, createChannel(channelId, blockFloorLight2, channelBus))
script4.spawn(blockFloorLight3, { "startOn": true, "clickable": true }, createChannel(channelId, blockFloorLight3, channelBus))
script5.spawn(imageBillboardBlack, { "image": "https://source.unsplash.com/random" }, createChannel(channelId, imageBillboardBlack, channelBus))
script6.spawn(externalLink, { "url": "project-managment.vercel.app/", "name": "Fill Your Timesheet" }, createChannel(channelId, externalLink, channelBus))