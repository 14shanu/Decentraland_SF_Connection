
export async function postData(url, data) {
    // Default options are marked with *
    const response = await fetch(url, {
        method: 'POST', // *GET, POST, PUT, DELETE, etc.

        headers: {
            'Content-Type': 'application/json'
            // 'Content-Type': 'application/x-www-form-urlencoded',
        },
        //   redirect: 'follow', // manual, *follow, error
        body: JSON.stringify(data) // body data type must match "Content-Type" header
    });
    return response.json(); // parses JSON response into native JavaScript objects
}
// export async function getEvents() {
//     const events: any[] = []
//     const url = 'http://localhost:8001'

//     try {

//         const response = await fetch(url)
//         const json = await response.json()

//         log(json)
//         // console.log(json)
//         for (const event of json.data) {
//             if (event.live) {
//                 events.push(event)
//             }
//         }

//         log(events)
//         return events
//     } catch (e) {
//         log('error getting event data ', e)
//     }
// }





